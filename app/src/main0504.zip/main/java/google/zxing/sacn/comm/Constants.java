package google.zxing.sacn.comm;

public class Constants {
	public static final String SCAN_RESULT = "SCAN_RESULT";
	public static final int SCAN_CODE = 00122;
}
