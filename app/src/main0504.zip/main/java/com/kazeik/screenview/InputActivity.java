package com.kazeik.screenview;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import butterknife.ButterKnife;
import butterknife.InjectView;
import butterknife.OnClick;

public class InputActivity extends Activity {

    @InjectView(R.id.tv_titleName)
    TextView tvTitleName;
    @InjectView(R.id.iv_left)
    ImageView ivLeft;
    @InjectView(R.id.et_value)
    EditText etValue;
    @InjectView(R.id.btn_screen)
    Button btnScreen;
    @InjectView(R.id.btn_check)
    Button btnCheck;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_input);
        ButterKnife.inject(this);

        ivLeft.setVisibility(View.VISIBLE);

    }

    @OnClick({R.id.iv_left, R.id.btn_screen, R.id.btn_check})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.iv_left:
                finish();
                break;
            case R.id.btn_screen:
                break;
            case R.id.btn_check:
                break;
        }
    }
}
